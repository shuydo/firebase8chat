import React from 'react';

const Message = () => {
    return (
        <div>

        </div>
    );
};

export default Message;
